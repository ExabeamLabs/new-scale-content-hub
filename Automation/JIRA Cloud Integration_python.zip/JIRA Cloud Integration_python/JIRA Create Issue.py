import jira
from requests import ConnectionError


class JiraException(Exception):
    pass

def from_connection_error(e):
    return f"Connection error: {str(e)}"

def get_jira_api(server_url: str, username: str, api_token: str):
    try:
        jira_api = jira.JIRA(server=server_url, basic_auth=(username, api_token), timeout=30)
    except jira.exceptions.JIRAError as e:
        raise JiraException(f"Connection to Jira at {server_url} failed: { e.status_code} ({e.response.reason})")
    except ConnectionError as e:
        raise JiraException(from_connection_error(e))

    return jira_api

def create_jira_issue(jira_api: jira.JIRA, project: str, issue_type: str, summary: str, assignee: str = None, description: str = None):
    """Create new JIRA issue"""
    if not (project and issue_type and summary):
        return False

    issue_creation_kwargs = {
        'project': project,
        'issuetype': {'name': issue_type},
        'summary': summary,
    }

    # Populate Optional Fields ONLY if they are provided
    if assignee:
        issue_creation_kwargs['assignee'] = {'name': assignee}

    if description:
        issue_creation_kwargs['description'] = description

    try:
        issue = jira_api.create_issue(**issue_creation_kwargs)
    except jira.exceptions.JIRAError as e:
        text = e.text if e.text else str(e)
        raise JiraException(text)
    
    return issue.key


def main(jira_service_configuration: dict,
         summary: str, issue_type: str, project: str,
         assignee_user_id: str = None, description: str = None,
         **issue_data) -> str:
    """Create new JIRA issue"""

    server_url = jira_service_configuration['Jira Instance URL']
    username = jira_service_configuration['Username']
    api_token = jira_service_configuration['API Token']

    jira_api = get_jira_api(server_url=server_url, username=username, api_token=api_token)

    return create_jira_issue(jira_api=jira_api, project=project, issue_type=issue_type, summary=summary,
                             assignee=assignee_user_id, description=description,
                             **issue_data)

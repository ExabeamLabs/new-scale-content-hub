#import wmill
import jira
from requests import ConnectionError

class JiraException(Exception):
    pass

def from_connection_error(e):
    return f"Connection error: {str(e)}"

def get_jira_api(server_url: str, username: str, api_token: str):
    try:
        jira_api = jira.JIRA(server=server_url,
                             basic_auth=(username, api_token),
                             timeout=30)
    except jira.exceptions.JIRAError as e:
        raise JiraException(f"Connection to Jira at {server_url} failed: { e.status_code} ({e.response.reason})")
    except ConnectionError as e:
        raise JiraException(from_connection_error(e))

    return jira_api

def transition_issue(jira_api: jira.JIRA, issue_id: str, status: str) -> bool:
    if not (issue_id and status):
        return False
    
    # Enhanced status validation
    transitions = jira_api.transitions(issue_id)
    transitions_dict = {t['id']: t['name'] for t in transitions}
    if (status not in transitions_dict) and (status not in transitions_dict.values()):
        return False

    try:
        jira_api.transition_issue(issue_id, status)
    except jira.exceptions.JIRAError as e:
        text = e.text if e.text else str(e)
        raise JiraException(text)

    return True

def main(jira_service_configuration: dict, issue_id: str, status: str) -> bool:
    """Change status of an issue"""

    server_url = jira_service_configuration['Jira Instance URL']
    username = jira_service_configuration['Username']
    api_token = jira_service_configuration['API Token']

    jira_api = get_jira_api(server_url=server_url, username=username, api_token=api_token)
    return transition_issue(jira_api=jira_api, issue_id=issue_id, status=status)

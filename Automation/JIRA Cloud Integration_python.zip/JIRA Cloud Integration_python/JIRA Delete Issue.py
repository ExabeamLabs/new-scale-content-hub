#import wmill
import jira
from requests import ConnectionError
from typing import List


class JiraException(Exception):
    pass

def from_connection_error(e):
    return f"Connection error: {str(e)}"

def get_jira_api(server_url: str, username: str, api_token: str):
    try:
        jira_api = jira.JIRA(server=server_url,
                             basic_auth=(username, api_token),
                             timeout=30)
    except jira.exceptions.JIRAError as e:
        raise JiraException(f"Connection to Jira at {server_url} failed: { e.status_code} ({e.response.reason})")
    except ConnectionError as e:
        raise JiraException(from_connection_error(e))

    return jira_api

def delete_issues(jira_api: jira.JIRA, issue_ids: List[str]) -> bool:
    if not issue_ids:
        return False
    
    if isinstance(issue_ids, str):
        issue_ids = [issue_ids]

    exceptions = []
    for issue_id in issue_ids:
        try:
            jira_api.issue(issue_id).delete()
        except jira.exceptions.JIRAError as e:
            text = e.text if e.text else str(e)
            exceptions.append(text)
            #raise JiraException(text)

    if exceptions:
        raise JiraException('\n'.join(exceptions))

    return True

def main(jira_service_configuration: dict, issue_ids: List[str]) -> bool:
    """Delete a JIRA issue"""

    server_url = jira_service_configuration['Jira Instance URL']
    username = jira_service_configuration['Username']
    api_token = jira_service_configuration['API Token']

    jira_api = get_jira_api(server_url=server_url, username=username, api_token=api_token)
    return delete_issues(jira_api=jira_api, issue_ids=issue_ids)

"""Advanced Automation Management action — move AD computer objects between OUs.

This file implements a single SOAR action that moves a computer object
between Organizational Units (OUs) in Active Directory using LDAP. It is
designed to be executed by the SOAR orchestration engine via the `main`
entrypoint and is not intended to be imported as a library module.
"""

import datetime
from typing import List, Optional, Set

import ldap3
from ldap3.utils.dn import safe_rdn
from ldap3.utils.conv import escape_filter_chars


# -----------------------------------------------------------------------------
# region COMMON FUNCTIONS AND CLASSES
UAC_ACCOUNT_DISABLED = 0x2
FILETIME_NEVER_EXPIRES_VALUES = {0, 9223372036854775807}


class Time:
    """Local replacement for soar.utility.time_utils.Time"""

    @staticmethod
    def now() -> datetime.datetime:
        """
        Return current time as a datetime object in UTC.
        """
        return datetime.datetime.now(datetime.timezone.utc)

    @staticmethod
    def get_ldap_timestamp() -> int:
        """
        Return current time as Windows FILETIME (100-ns intervals since Jan 1, 1601 UTC).
        This matches typical AD/LDAP expectations for account expiration timestamps.
        """

        epoch = datetime.datetime(1601, 1, 1, tzinfo=datetime.timezone.utc)
        now = Time.now()
        return int((now - epoch).total_seconds() * 10**7)

    @staticmethod
    def filetime_to_datetime(filetime: int) -> Optional[datetime.datetime]:
        if not filetime or filetime in FILETIME_NEVER_EXPIRES_VALUES:
            return None
        epoch = datetime.datetime(1601, 1, 1, tzinfo=datetime.timezone.utc)
        return epoch + datetime.timedelta(seconds=filetime / 10**7)


class ExabeamConnectorException(Exception):
    """Local replacement for soar.utility.custom_exceptions.ExabeamConnectorException"""
    pass


def to_base_dn(domain: str) -> str:
    """Normalize a domain string into a base DN.

    If `domain` already contains `dc=` (case-insensitive) it is returned
    unchanged; otherwise `example.com` -> `dc=example,dc=com`.
    """
    if "dc=" in domain.lower():
        return domain
    return "dc=" + ",dc=".join(domain.split("."))


def extract_rdn_value(dn: str) -> str:
    """Return the value part of the first RDN using ldap3.safe_rdn.

    Falls back to a best-effort split if parsing fails.
    """
    try:
        r = safe_rdn(dn)
        if "=" in r:
            return r.split("=", 1)[1]
        return r
    except Exception:
        return dn


def create_connection(
    server: ldap3.Server, username: str, password: str
) -> ldap3.Connection:
    """
    Create and bind an ldap3.Connection using SIMPLE authentication.
    Returns a bound Connection object or raises ExabeamConnectorException.
    """

    try:
        conn = ldap3.Connection(
            server=server,
            user=username,
            password=password,
            auto_bind=True,
            raise_exceptions=True,
        )

    except ldap3.core.exceptions.LDAPInvalidCredentialsResult as e:
        raise ExabeamConnectorException(
            "Authentication failed: invalid username or password."
        ) from e

    except ldap3.core.exceptions.LDAPSocketOpenError as e:
        raise ExabeamConnectorException(
            f"Failed to connect to LDAP server {server.host}."
        ) from e

    except ldap3.core.exceptions.LDAPBindError as e:
        raise ExabeamConnectorException(
            "LDAP bind failed: server rejected authentication."
        ) from e

    except ldap3.core.exceptions.LDAPExceptionError as e:
        # Generic LDAP exceptions
        raise ExabeamConnectorException(
            f"Unexpected LDAP error: {e.__class__.__name__}"
        ) from e

    except Exception as e:
        # Unknown / connection layer
        raise ExabeamConnectorException(
            f"Unexpected error during LDAP connection: {e.__class__.__name__}"
        ) from e

    # Safety check
    if conn is None or not conn.bound:
        raise ExabeamConnectorException("LDAP connection created but not bound.")

    return conn
# endregion COMMON FUNCTIONS AND CLASSES
# -----------------------------------------------------------------------------


def _search_ou_dns(
    search_domain: str, ou_name: str, connection: ldap3.Connection
) -> List[str]:
    """Search for organizational units (OUs) by name under a search base.

    Args:
        search_domain: LDAP search base in DN format (for example
            'dc=example,dc=com').
        ou_name: Value of the OU `name` attribute to search for.
        connection: A bound `ldap3.Connection` used to perform the search.

    Returns:
        A list of distinguished names (DNs) for matching OUs. If nothing is
        found an empty list is returned.
    """

    ou_dns: List[str] = []
    escaped_ou = escape_filter_chars(ou_name)
    ous = connection.extend.standard.paged_search(
        search_base=search_domain,
        search_filter=f"(&(objectCategory=organizationalUnit)(name={escaped_ou}))",
        search_scope=ldap3.SUBTREE,
        attributes=["name"],
    )

    for ou in ous:
        if "dn" in ou:
            ou_dns.append(ou["dn"])

    return ou_dns


def change_ou(
    server: ldap3.Server,
    username: str,
    password: str,
    search_domains: List[str],
    target_host: str,
    target_ou: str,
) -> None:
    """Move a computer object to a target OU across provided domains.

    This function attempts to locate the specified computer object in each
    domain provided and, if found, moves it (by changing its DN's superior)
    to the first matching target OU found in that domain.

    Args:
        server: A configured `ldap3.Server` instance used for connections.
        username: Bind DN or username for LDAP authentication.
        password: Password for LDAP authentication.
        search_domains: List of domain strings in DNS form (e.g. ['example.com']).
        target_host: Computer object name to move (sAMAccountName / `name`).
        target_ou: The OU `name` attribute indicating the target OU.

    Raises:
        ExabeamConnectorException: If the move operation fails for all
            supplied domains. The exception message will aggregate per-domain
            errors.
    """

    exceptions: Set[str] = set()
    success = False

    for search_dom in search_domains:
        search_domain = to_base_dn(search_dom)
        with create_connection(server, username, password) as connection:
            ou_dns = _search_ou_dns(search_domain, target_ou, connection)
            if not ou_dns:
                exceptions.add(f"{target_ou} not found in {search_dom}")
                continue

            escaped_host = escape_filter_chars(target_host)
            try:
                computers = connection.extend.standard.paged_search(
                    search_base=search_domain,
                    search_filter=f"(&(objectCategory=computer)(name={escaped_host}))",
                    search_scope=ldap3.SUBTREE,
                    attributes=["name"],
                )
            except ldap3.core.exceptions.LDAPExceptionError as e:
                exceptions.add(str(e))
                continue

            dn_found = False
            for computer in computers:
                if "dn" in computer:
                    dn = computer["dn"]
                    rdn = safe_rdn(dn)
                    dn_found = True
                    for ou in ou_dns:
                        try:
                            connection.modify_dn(dn, rdn, new_superior=ou)
                            success = True
                        except ldap3.core.exceptions.LDAPExceptionError as e:
                            exceptions.add(
                                f"failed to change {ou} for {dn} in {search_dom}: {e}"
                            )
            if not dn_found:
                exceptions.add(f"{target_host} not found in {search_dom}")

    if not success:
        raise ExabeamConnectorException(", ".join(exceptions))


def main(
    ldap_authentication_data: dict, target_ou: str, target_hosts: List[str]
) -> dict:
    """Entry point to change computer object OUs for multiple hosts.

    Args:
        ldap_authentication_data: Dictionary containing LDAP connection
            configuration. Expected keys include: `server_address`, `domains`
            (comma-separated), `username`, `password`, and `use_ssl`.
        target_ou: Name of the destination OU (value of the `name` attribute).
        target_hosts: List of computer names to move.

    Returns:
        A dictionary summarizing per-host results and overall operation status.
    """

    timestamp = Time.now().isoformat()

    # Empty input fallback
    if not all([target_ou, target_hosts]):
        return {
            "success": True,
            "status": "success",
            "message": "No targets provided; nothing to process.",
            "timestamp": timestamp,
            "results": [],
            "errors": [],
        }

    # ----- Get Instance Configuration Fields -----
    server_address = ldap_authentication_data.get("server_address")
    bind_user = ldap_authentication_data.get("username", "")
    bind_password = ldap_authentication_data.get("password", "")
    use_ssl = ldap_authentication_data.get("use_ssl", False)
    if isinstance(use_ssl, str):
        use_ssl = use_ssl.lower() in ('t', 'true')
    port = 636 if use_ssl else 389
    domains = ldap_authentication_data.get("domains", "")
    domains = [d.strip() for d in str(domains).split(",") if d.strip()]

    server = ldap3.Server(
        host=server_address,
        port=port,
        get_info=ldap3.ALL,
        allowed_referral_hosts=[("*", True)],
        use_ssl=use_ssl,
    )

    # ----- Build domains_dict (DNS domain -> base DN) -----
    if not domains:
        default_nc = (
            (getattr(server, "info", None) and server.info.other.get("defaultNamingContext"))
            or []
        )
        base_dn = default_nc[0] if default_nc else ""
        if not base_dn:
            raise ExabeamConnectorException(
                "No domains provided and defaultNamingContext could not be determined."
            )

        domain = base_dn.lower().replace("dc=", "").replace(",", ".")
        domains_dict = {domain: base_dn}
    else:
        domains_dict = {domain: to_base_dn(domain) for domain in domains}

    results = []
    exceptions = []

    for target_host in target_hosts:
        try:
            change_ou(
                server=server,
                username=bind_user,
                password=bind_password,
                search_domains=domains,
                target_host=target_host,
                target_ou=target_ou,
            )

            result = {
                "target": target_host,
                "success": True,
                "message": "OU successfully changed.",
                "changed": True,
                "details": {"target_ou": target_ou, "domain": server_address},
                "errors": [],
                "timestamp": timestamp,
            }

        except ExabeamConnectorException as e:
            exc_text = str(e)
            exceptions.append(exc_text)

            result = {
                "target": target_host,
                "success": False,
                "message": "Failed to change OU.",
                "changed": False,
                "details": {"target_ou": target_ou, "domain": server_address},
                "errors": [exc_text],
                "timestamp": timestamp,
            }

        results.append(result)

    if not results:
        top_success = False
        top_message = "No operations were performed."
    else:
        all_ok = all(r["success"] for r in results)
        any_ok = any(r["success"] for r in results)
        if all_ok:
            top_success = True
            top_message = "All operations completed successfully."
        elif any_ok:
            top_success = False
            top_message = "Completed with errors."
        else:
            top_success = False
            top_message = "All operations failed."

    return {
        "success": top_success,
        "results": results,
        "errors": exceptions,
        "message": top_message,
        "timestamp": timestamp,
    }

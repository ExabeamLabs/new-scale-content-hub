"""Advanced Automation Management action — update an attribute on AD computer objects.

This file implements a single SOAR action that updates a specified
attribute on a computer object in Active Directory via LDAP. It is
intended to run as a SOAR action (using the `main` entrypoint) rather
than be imported as a reusable library module.
"""

import datetime
from typing import Any, Dict, List, Optional

import ldap3
from ldap3.utils.conv import escape_filter_chars
from ldap3.utils.dn import safe_rdn


# -----------------------------------------------------------------------------
# region COMMON FUNCTIONS AND CLASSES
UAC_ACCOUNT_DISABLED = 0x2
FILETIME_NEVER_EXPIRES_VALUES = {0, 9223372036854775807}


class Time:
    """Local replacement for soar.utility.time_utils.Time"""

    @staticmethod
    def now() -> datetime.datetime:
        """Return current time as a datetime object in UTC."""
        return datetime.datetime.now(datetime.timezone.utc)

    @staticmethod
    def get_ldap_timestamp() -> int:
        """Return current time as Windows FILETIME (100-ns intervals since Jan 1, 1601 UTC)."""
        epoch = datetime.datetime(1601, 1, 1, tzinfo=datetime.timezone.utc)
        now = Time.now()
        return int((now - epoch).total_seconds() * 10**7)

    @staticmethod
    def filetime_to_datetime(filetime: int) -> Optional[datetime.datetime]:
        if not filetime or filetime in FILETIME_NEVER_EXPIRES_VALUES:
            return None
        epoch = datetime.datetime(1601, 1, 1, tzinfo=datetime.timezone.utc)
        return epoch + datetime.timedelta(seconds=filetime / 10**7)


class ExabeamConnectorException(Exception):
    """Local replacement for soar.utility.custom_exceptions.ExabeamConnectorException"""
    pass


def to_base_dn(domain: str) -> str:
    """Normalize a domain string into a base DN.

    If `domain` already contains `dc=` (case-insensitive) it is returned
    unchanged; otherwise `example.com` -> `dc=example,dc=com`.
    """
    if "dc=" in domain.lower():
        return domain
    return "dc=" + ",dc=".join(domain.split("."))


def first_value(v: Any) -> Any:
    """Return the first element if v is a list/tuple, else v."""
    if v is None:
        return None
    if isinstance(v, (list, tuple)) and v:
        return v[0]
    return v


def extract_rdn_value(dn: Any) -> str:
    """
    Return the *value* part of the first RDN (CN=..., OU=..., etc.).
    Always returns a string (never list/tuple), even if ldap3.safe_rdn behaves oddly.
    """
    dn = first_value(dn)
    if dn is None:
        return ""

    if isinstance(dn, (bytes, bytearray)):
        dn = dn.decode("utf-8", errors="replace")
    if not isinstance(dn, str):
        dn = str(dn)

    # Take only the first RDN (before the first comma)
    first_rdn = dn.split(",", 1)[0].strip()

    def _parse_value(rdn: str) -> str:
        if "=" not in rdn:
            return rdn
        val = rdn.split("=", 1)[1]
        # multi-valued RDN like "CN=a+OU=b"
        if "+" in val:
            val = val.split("+", 1)[0]
        return val

    try:
        r = safe_rdn(first_rdn)

        # safe_rdn can return non-str in edge cases; never return it directly
        r = first_value(r)
        if r is None:
            return _parse_value(first_rdn)
        if not isinstance(r, str):
            r = str(r)

        return _parse_value(r)

    except Exception:
        return _parse_value(first_rdn)


def create_connection(
    server: ldap3.Server, username: str, password: str
) -> ldap3.Connection:
    """Create and bind an ldap3.Connection using SIMPLE authentication."""
    try:
        conn = ldap3.Connection(
            server=server,
            user=username,
            password=password,
            auto_bind=True,
            raise_exceptions=True,
        )

    except ldap3.core.exceptions.LDAPInvalidCredentialsResult as e:
        raise ExabeamConnectorException(
            "Authentication failed: invalid username or password."
        ) from e

    except ldap3.core.exceptions.LDAPSocketOpenError as e:
        raise ExabeamConnectorException(
            f"Failed to connect to LDAP server {server.host}."
        ) from e

    except ldap3.core.exceptions.LDAPBindError as e:
        raise ExabeamConnectorException(
            "LDAP bind failed: server rejected authentication."
        ) from e

    except ldap3.core.exceptions.LDAPExceptionError as e:
        raise ExabeamConnectorException(
            f"Unexpected LDAP error: {e.__class__.__name__}"
        ) from e

    except Exception as e:
        raise ExabeamConnectorException(
            f"Unexpected error during LDAP connection: {e.__class__.__name__}"
        ) from e

    if conn is None or not conn.bound:
        raise ExabeamConnectorException("LDAP connection created but not bound.")

    return conn
# endregion COMMON FUNCTIONS AND CLASSES
# -----------------------------------------------------------------------------


def set_host_attribute(
    server: ldap3.Server,
    bind_user: str,
    password: str,
    domains_dict: Dict[str, str],
    hostname: str,
    attribute_name: str,
    attribute_value: str,
) -> dict:
    """Update a single attribute on a computer object across domains.

    Args:
        server: Configured ldap3.Server
        bind_user: Bind DN/username
        password: Bind password
        domains_dict: Mapping of DNS domain -> base DN
        hostname: Computer name (value of `name` attribute)
        attribute_name: Attribute to replace
        attribute_value: Replacement value
    """
    timestamp = Time.now().isoformat()
    errors: List[str] = []

    try:
        with create_connection(server, bind_user, password) as connection:
            for domain, base_dn in domains_dict.items():
                safe_hostname = escape_filter_chars(hostname)
                connection.search(
                    search_base=base_dn,
                    search_filter=f"(&(objectClass=computer)(name={safe_hostname}))",
                    search_scope=ldap3.SUBTREE,
                )

                entries = connection.entries
                if not entries:
                    errors.append(f"{hostname} not found in domain {domain}")
                    continue

                for ent in entries:
                    dn = ent.entry_dn
                    try:
                        connection.modify(
                            dn,
                            {attribute_name: [(ldap3.MODIFY_REPLACE, [attribute_value])]},
                        )

                        if connection.result.get("result") == 0:
                            return {
                                "target": hostname,
                                "success": True,
                                "message": f"Attribute '{attribute_name}' updated successfully.",
                                "timestamp": timestamp,
                                "details": {
                                    "domain": domain,
                                    "base_dn": base_dn,
                                    "attribute": attribute_name,
                                    "value": attribute_value,
                                    "distinguished_name": dn,
                                },
                                "exception": None,
                            }

                        errors.append(
                            connection.result.get("message", "Unknown LDAP error")
                        )
                    except ldap3.core.exceptions.LDAPExceptionError as e:
                        errors.append(str(e))

    except ExabeamConnectorException as e:
        errors.append(str(e))

    return {
        "target": hostname,
        "success": False,
        "message": "Failed to update host attribute.",
        "timestamp": timestamp,
        "details": {"attribute": attribute_name, "value": attribute_value},
        "exception": "; ".join(errors) if errors else "Unknown failure",
    }


def main(
    ldap_authentication_data: dict,
    target_hosts: List[str],
    attribute_name: str,
    attribute_value: str,
) -> dict:
    """Entry point to update an attribute for multiple hostnames."""
    timestamp = Time.now().isoformat()

    # Empty input fallback
    if not all([target_hosts, attribute_name, attribute_value]):
        return {
            "success": True,
            "status": "success",
            "message": "No input provided; nothing to process.",
            "timestamp": timestamp,
            "results": [],
            "errors": [],
        }

    # ----- Instance configuration -----
    server_address = ldap_authentication_data.get("server_address", "")
    bind_user = ldap_authentication_data.get("username", "")
    bind_password = ldap_authentication_data.get("password", "")
    use_ssl: bool = ldap_authentication_data.get("use_ssl", False)
    if isinstance(use_ssl, str):
        use_ssl = use_ssl.lower() in ('t', 'true')
    port = 636 if use_ssl else 389

    domains = ldap_authentication_data.get("domains", "")
    domains = [d.strip() for d in str(domains).split(",") if d.strip()]

    server = ldap3.Server(
        host=server_address,
        port=port,
        get_info=ldap3.ALL,
        allowed_referral_hosts=[("*", True)],
        use_ssl=use_ssl,
    )

    # ----- Build domains_dict (DNS domain -> base DN) -----
    if not domains:
        default_nc = (
            (getattr(server, "info", None) and server.info.other.get("defaultNamingContext"))
            or []
        )
        base_dn = default_nc[0] if default_nc else ""
        if not base_dn:
            raise ExabeamConnectorException(
                "No domains provided and defaultNamingContext could not be determined."
            )

        domain = base_dn.lower().replace("dc=", "").replace(",", ".")
        domains_dict = {domain: base_dn}
    else:
        domains_dict = {domain: to_base_dn(domain) for domain in domains}

    results = []
    errors = []

    for hostname in target_hosts:
        result = set_host_attribute(
            server=server,
            bind_user=bind_user,
            password=bind_password,
            domains_dict=domains_dict,
            hostname=hostname,
            attribute_name=attribute_name,
            attribute_value=attribute_value,
        )

        results.append(result)

        if not result["success"] and result.get("exception"):
            errors.append(f"{hostname}: {result['exception']}")

    success_count = sum(1 for r in results if r["success"])
    failure_count = len(results) - success_count

    if failure_count == 0:
        status = "success"
        success = True
        message = "All host attributes updated successfully."
    elif success_count > 0:
        status = "partial_success"
        success = False
        message = "Some host attributes failed to update."
    else:
        status = "failure"
        success = False
        message = "All host attribute updates failed."

    return {
        "success": success,
        "status": status,
        "message": message,
        "timestamp": timestamp,
        "results": results,
        "errors": errors,
    }

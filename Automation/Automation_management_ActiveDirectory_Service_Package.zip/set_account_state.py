"""Advanced Automation Management action — enable or disable AD user accounts.

This file implements a SOAR action that toggles a user's enabled/disabled
state in Active Directory via LDAP. It is intended to be run as a SOAR
action (using the `main` entrypoint) and is not designed for import as
a general-purpose library module.
"""

import datetime
from typing import Any, Dict, List, Optional, Set

import ldap3
from ldap3.utils.conv import escape_filter_chars
from ldap3.utils.dn import safe_rdn


ACCOUNT_STATE_VALUES_CODES = {"Enabled": 512, "Disabled": 514}

# -----------------------------------------------------------------------------
# region COMMON FUNCTIONS AND CLASSES
UAC_ACCOUNT_DISABLED = 0x2
FILETIME_NEVER_EXPIRES_VALUES = {0, 9223372036854775807}


class Time:
    """Local replacement for soar.utility.time_utils.Time"""

    @staticmethod
    def now() -> datetime.datetime:
        """Return current time as a datetime object in UTC."""
        return datetime.datetime.now(datetime.timezone.utc)

    @staticmethod
    def get_ldap_timestamp() -> int:
        """Return current time as Windows FILETIME (100-ns intervals since Jan 1, 1601 UTC)."""
        epoch = datetime.datetime(1601, 1, 1, tzinfo=datetime.timezone.utc)
        now = Time.now()
        return int((now - epoch).total_seconds() * 10**7)

    @staticmethod
    def filetime_to_datetime(filetime: int) -> Optional[datetime.datetime]:
        if not filetime or filetime in FILETIME_NEVER_EXPIRES_VALUES:
            return None
        epoch = datetime.datetime(1601, 1, 1, tzinfo=datetime.timezone.utc)
        return epoch + datetime.timedelta(seconds=filetime / 10**7)


class ExabeamConnectorException(Exception):
    """Local replacement for soar.utility.custom_exceptions.ExabeamConnectorException"""
    pass


def to_base_dn(domain: str) -> str:
    """Normalize a domain string into a base DN."""
    if "dc=" in domain.lower():
        return domain
    return "dc=" + ",dc=".join(domain.split("."))


def first_value(v: Any) -> Any:
    """Return the first element if v is a list/tuple, else v."""
    if v is None:
        return None
    if isinstance(v, (list, tuple)) and v:
        return v[0]
    return v


def _flatten(values: Any) -> List[str]:
    """
    Normalize LDAP attribute values to a flat list of strings.
    Handles: None, str, bytes, list[str], list[list[str]], tuples, sets, etc.
    """
    if values is None:
        return []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (bytes, bytearray)):
        try:
            return [values.decode("utf-8", errors="replace")]
        except Exception:
            return [str(values)]

    if isinstance(values, (list, tuple, set)):
        out: List[str] = []
        for v in values:
            out.extend(_flatten(v))
        return out

    return [str(values)]


def extract_rdn_value(dn: Any) -> str:
    """
    Return the *value* part of the first RDN (CN=..., OU=..., etc.).
    Always returns a string (never list/tuple), even if ldap3.safe_rdn behaves oddly.
    """
    dn = first_value(dn)
    if dn is None:
        return ""

    if isinstance(dn, (bytes, bytearray)):
        dn = dn.decode("utf-8", errors="replace")
    if not isinstance(dn, str):
        dn = str(dn)

    # Take only the first RDN (before the first comma)
    first_rdn = dn.split(",", 1)[0].strip()

    def _parse_value(rdn: str) -> str:
        if "=" not in rdn:
            return rdn
        val = rdn.split("=", 1)[1]
        # multi-valued RDN like "CN=a+OU=b"
        if "+" in val:
            val = val.split("+", 1)[0]
        return val

    try:
        r = safe_rdn(first_rdn)

        r = first_value(r)
        if r is None:
            return _parse_value(first_rdn)
        if not isinstance(r, str):
            r = str(r)

        return _parse_value(r)

    except Exception:
        return _parse_value(first_rdn)


def create_connection(
    server: ldap3.Server, username: str, password: str
) -> ldap3.Connection:
    """Create and bind an ldap3.Connection using SIMPLE authentication."""
    try:
        conn = ldap3.Connection(
            server=server,
            user=username,
            password=password,
            auto_bind=True,
            raise_exceptions=True,
        )

    except ldap3.core.exceptions.LDAPInvalidCredentialsResult as e:
        raise ExabeamConnectorException(
            "Authentication failed: invalid username or password."
        ) from e

    except ldap3.core.exceptions.LDAPSocketOpenError as e:
        raise ExabeamConnectorException(
            f"Failed to connect to LDAP server {server.host}."
        ) from e

    except ldap3.core.exceptions.LDAPBindError as e:
        raise ExabeamConnectorException(
            "LDAP bind failed: server rejected authentication."
        ) from e

    except ldap3.core.exceptions.LDAPExceptionError as e:
        raise ExabeamConnectorException(
            f"Unexpected LDAP error: {e.__class__.__name__}"
        ) from e

    except Exception as e:
        raise ExabeamConnectorException(
            f"Unexpected error during LDAP connection: {e.__class__.__name__}"
        ) from e

    if conn is None or not conn.bound:
        raise ExabeamConnectorException("LDAP connection created but not bound.")

    return conn
# endregion COMMON FUNCTIONS AND CLASSES
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# region USER INFO FUNCTIONS
def is_account_locked(attrs: dict) -> bool:
    """
    Determine if an AD account is locked based on lockoutTime.

    lockoutTime is a Windows FILETIME; semantics:
      - 0 / 1601-01-01 => not locked
      - >0 / later than 1601 => locked

    ldap3 may surface it as int, numeric string, datetime string, datetime object, or list.
    """
    lockout_time = first_value(attrs.get("lockoutTime"))

    if lockout_time is None:
        return False

    # bytes -> str
    if isinstance(lockout_time, (bytes, bytearray)):
        lockout_time = lockout_time.decode("utf-8", errors="replace")

    # datetime -> compare against sentinel
    if isinstance(lockout_time, datetime.datetime):
        # Normalize timezone: treat naive as UTC (common enough in some environments)
        if lockout_time.tzinfo is None:
            lockout_time = lockout_time.replace(tzinfo=datetime.timezone.utc)

        sentinel = datetime.datetime(1601, 1, 1, tzinfo=datetime.timezone.utc)
        return lockout_time > sentinel

    # empty-ish
    if lockout_time in ("", 0, "0"):
        return False

    # string forms (sentinel or numeric)
    if isinstance(lockout_time, str):
        s = lockout_time.strip()
        if s.startswith("1601-01-01 00:00:00"):
            return False
        try:
            return int(s) > 0
        except ValueError:
            # datetime-ish string that's not the sentinel => locked
            return True

    # numeric-like
    try:
        return int(lockout_time) > 0
    except (TypeError, ValueError):
        # unknown non-empty type => assume locked (safer default)
        return True


def get_account_expiration_data(attrs: dict) -> dict:
    """
    Determine if account is expired based on accountExpires.
    AD semantics:
      - 0 or 9223372036854775807 => never expires
      - Some libraries surface "never" as 1601-01-01T00:00:00Z (FILETIME epoch)
    """
    raw = first_value(attrs.get("accountExpires"))

    if raw in (None, "", 0, "0"):
        return {"account_expired": False, "account_expires_at_dt": None}

    if isinstance(raw, (bytes, bytearray)):
        raw = raw.decode("utf-8", errors="replace")

    sentinel_dt = datetime.datetime(1601, 1, 1, tzinfo=datetime.timezone.utc)

    # datetime returned by ldap3
    if isinstance(raw, datetime.datetime):
        expiry_time = raw
        if expiry_time.tzinfo is None:
            expiry_time = expiry_time.replace(tzinfo=datetime.timezone.utc)

        # Treat 1601-01-01 (or earlier) as "never"
        if expiry_time <= sentinel_dt:
            return {"account_expired": False, "account_expires_at_dt": None}

        return {
            "account_expired": expiry_time < Time.now(),
            "account_expires_at_dt": expiry_time,
        }

    # string returned by ldap3 (could be numeric FILETIME or datetime-ish)
    if isinstance(raw, str):
        s = raw.strip()

        # Handle both "1601-01-01 00:00:00..." and ISO "1601-01-01T00:00:00..."
        if s.startswith("1601-01-01 00:00:00") or s.startswith("1601-01-01T00:00:00"):
            return {"account_expired": False, "account_expires_at_dt": None}

        # Numeric string FILETIME?
        try:
            expires = int(s)
        except ValueError:
            # datetime-ish string (best effort)
            try:
                expiry_time = datetime.datetime.fromisoformat(s)
                if expiry_time.tzinfo is None:
                    expiry_time = expiry_time.replace(tzinfo=datetime.timezone.utc)

                if expiry_time <= sentinel_dt:
                    return {"account_expired": False, "account_expires_at_dt": None}

                return {
                    "account_expired": expiry_time < Time.now(),
                    "account_expires_at_dt": expiry_time,
                }
            except Exception:
                return {"account_expired": False, "account_expires_at_dt": None}
    else:
        # numeric-like FILETIME
        try:
            expires = int(raw)
        except (TypeError, ValueError):
            return {"account_expired": False, "account_expires_at_dt": None}

    # numeric FILETIME sentinel values mean "never"
    if expires in FILETIME_NEVER_EXPIRES_VALUES or expires <= 0:
        return {"account_expired": False, "account_expires_at_dt": None}

    expiry_time = Time.filetime_to_datetime(expires)
    if expiry_time is None:
        return {"account_expired": False, "account_expires_at_dt": None}

    # If filetime_to_datetime ever yields epoch, treat as "never"
    if expiry_time <= sentinel_dt:
        return {"account_expired": False, "account_expires_at_dt": None}

    return {
        "account_expired": expiry_time < Time.now(),
        "account_expires_at_dt": expiry_time,
    }




def get_password_expiration_data(attrs: dict, max_pwd_age_seconds: int) -> dict:
    result: Dict[str, object] = {
        "password_expired": False,
        "must_change_password": False,
        "password_expires_at_dt": None,
    }

    raw = first_value(attrs.get("pwdLastSet"))

    # Treat missing as "unknown/not expired" (keep your existing behavior)
    if raw is None or raw == "":
        return result

    # bytes -> str
    if isinstance(raw, (bytes, bytearray)):
        raw = raw.decode("utf-8", errors="replace")

    sentinel_dt = datetime.datetime(1601, 1, 1, tzinfo=datetime.timezone.utc)

    # datetime -> interpret epoch as "must change"
    if isinstance(raw, datetime.datetime):
        pwd_set_time = raw
        if pwd_set_time.tzinfo is None:
            pwd_set_time = pwd_set_time.replace(tzinfo=datetime.timezone.utc)

        # 1601 epoch effectively means 0 / must change
        if pwd_set_time <= sentinel_dt:
            result["password_expired"] = True
            result["must_change_password"] = True
            return result

    # string handling
    if isinstance(raw, str):
        s = raw.strip()

        # "0" => must change
        if s == "0":
            result["password_expired"] = True
            result["must_change_password"] = True
            return result

        # Some serializers use epoch strings for "0"
        if s.startswith("1601-01-01 00:00:00") or s.startswith("1601-01-01T00:00:00"):
            result["password_expired"] = True
            result["must_change_password"] = True
            return result

        # numeric string FILETIME?
        try:
            pwd_last_set = int(s)
        except ValueError:
            # datetime-ish string best effort
            try:
                pwd_set_time = datetime.datetime.fromisoformat(s)
                if pwd_set_time.tzinfo is None:
                    pwd_set_time = pwd_set_time.replace(tzinfo=datetime.timezone.utc)

                if pwd_set_time <= sentinel_dt:
                    result["password_expired"] = True
                    result["must_change_password"] = True
                    return result
            except Exception:
                return result
        else:
            if pwd_last_set == 0:
                result["password_expired"] = True
                result["must_change_password"] = True
                return result

            pwd_set_time = Time.filetime_to_datetime(pwd_last_set)
            if not pwd_set_time:
                return result

    # non-str, non-datetime numeric-like
    if not isinstance(raw, (str, datetime.datetime)):
        try:
            pwd_last_set = int(raw)
        except (TypeError, ValueError):
            return result

        if pwd_last_set == 0:
            result["password_expired"] = True
            result["must_change_password"] = True
            return result

        pwd_set_time = Time.filetime_to_datetime(pwd_last_set)
        if not pwd_set_time:
            return result

    # If no policy, we can only reliably report must_change (handled above)
    if not max_pwd_age_seconds:
        return result

    # If we got here and have pwd_set_time, compute expiration
    # (pwd_set_time is guaranteed defined if policy is present and value was usable)
    expiry_time = pwd_set_time + datetime.timedelta(seconds=max_pwd_age_seconds)
    result["password_expired"] = expiry_time < Time.now()
    result["password_expires_at_dt"] = expiry_time
    return result



def is_account_disabled(attrs: dict) -> bool:
    raw = first_value(attrs.get("userAccountControl"))
    try:
        return bool(int(raw or 0) & UAC_ACCOUNT_DISABLED)
    except (TypeError, ValueError):
        return False


def get_domain_max_pwd_age_seconds(connection: ldap3.Connection, base_dn: str) -> int:
    """Retrieve maxPwdAge for a domain and return seconds."""
    connection.search(
        search_base=base_dn,
        search_scope=ldap3.BASE,
        search_filter="(objectClass=domainDNS)",
        attributes=["maxPwdAge"],
    )

    if not connection.entries:
        return 0

    raw_max_age_value = first_value(connection.entries[0]["maxPwdAge"].value)
    if not raw_max_age_value:
        return 0

    try:
        max_pwd_age = int(raw_max_age_value)
    except (TypeError, ValueError):
        return 0

    return abs(max_pwd_age) // 10_000_000


def _search_user_info(
    connection: ldap3.Connection,
    username: str,
    base_dn: str,
    filters: Optional[List[str]],
) -> Optional[dict]:
    """Search for a user in the specified domain using provided filters."""
    filters = filters or active_directory_filters()

    safe_username = escape_filter_chars(username)
    for search_filter in filters:
        connection.search(
            search_base=base_dn,
            search_scope=ldap3.SUBTREE,
            search_filter=search_filter.format(safe_username),
            attributes=["*"],
        )
        if connection.entries:
            break

    if not connection.entries:
        return None

    entry = connection.entries[0]
    return {"dn": entry.entry_dn, "attributes": entry.entry_attributes_as_dict}


def active_directory_filters() -> List[str]:
    """Return the default AD user search filters."""
    return [
        "(&(objectCategory=person)(objectClass=user)(name={}))",
        "(&(objectCategory=person)(objectClass=user)(displayName={}))",
        "(&(objectCategory=person)(objectClass=user)(cn={}))",
        "(&(objectCategory=person)(objectClass=user)(sAMAccountName={}))",
        "(&(objectCategory=person)(objectClass=user)(mail={}))",
    ]


def get_user_info(
    server: ldap3.Server,
    bind_user: str,
    password: str,
    domains_dict: Dict[str, str],
    target_username: str,
    domain_policy_cache: Dict[str, Optional[int]],
    filters: Optional[List[str]] = None,
) -> List[dict]:
    """Search for a user across the provided domains and return enriched entries."""
    filters = filters or active_directory_filters()

    results = []
    exceptions: Set[str] = set()

    with create_connection(server=server, username=bind_user, password=password) as connection:
        for domain, domain_dn in domains_dict.items():
            item_timestamp = Time.now().isoformat()
            try:
                response = _search_user_info(
                    connection=connection,
                    username=target_username,
                    base_dn=domain_dn,
                    filters=filters,
                )
                if not response:
                    continue
                response["domain"] = domain

            except (ldap3.core.exceptions.LDAPExceptionError, ExabeamConnectorException) as e:
                exceptions.add(str(e))
                continue

            try:
                if domain not in domain_policy_cache:
                    domain_policy_cache[domain] = get_domain_max_pwd_age_seconds(
                        connection=connection, base_dn=domain_dn
                    )
            except ldap3.core.exceptions.LDAPExceptionError as e:
                exceptions.add(str(e))

            attrs = response.get("attributes", {})
            name = first_value(attrs.get("name")) or ""
            sam_account_name = first_value(attrs.get("sAMAccountName")) or ""

            groups: Set[str] = set()
            member_of = _flatten(attrs.get("memberOf") or [])
            for group_dn in member_of:
                val = extract_rdn_value(group_dn)
                if val:
                    groups.add(val)

            account_state = "Disabled" if is_account_disabled(attrs) else "Enabled"

            account_expired_dict = get_account_expiration_data(attrs)
            account_expired = account_expired_dict.get("account_expired", False)
            account_expires_at_dt = account_expired_dict.get("account_expires_at_dt")
            account_expires_at = (
                account_expires_at_dt.isoformat() if account_expires_at_dt else None
            )

            account_locked = is_account_locked(attrs)

            max_pwd_age: int = domain_policy_cache.get(domain) or 0
            password_expired_dict = get_password_expiration_data(attrs, max_pwd_age)
            password_expired = password_expired_dict.get("password_expired", False)
            must_change_password = password_expired_dict.get("must_change_password", False)

            password_expires_at_dt = password_expired_dict.get("password_expires_at_dt")
            password_expires_at = (
                password_expires_at_dt.isoformat() if password_expires_at_dt else None
            )

            results.append(
                {
                    "target": target_username,
                    "success": True,
                    "message": "User information retrieved successfully.",
                    "timestamp": item_timestamp,
                    "details": {
                        "name": name,
                        "sAMAccountName": sam_account_name,
                        "domain": domain,
                        "distinguished_name": response["dn"],
                        "groups": list(sorted(groups)),
                        "account_state": account_state,
                        "account_expired": account_expired,
                        "account_expires_at": account_expires_at,
                        "account_locked": account_locked,
                        "password_expired": password_expired,
                        "must_change_password": must_change_password,
                        "password_expires_at": password_expires_at,
                    },
                    "exception": None,
                }
            )

    if not results and exceptions:
        raise ExabeamConnectorException(", ".join(exceptions))

    return results
# endregion USER INFO FUNCTIONS
# -----------------------------------------------------------------------------


def change_account_state(
    server: ldap3.Server,
    bind_user: str,
    password: str,
    domains_dict: Dict[str, str],
    target_username: str,
    domain_policy_cache: Dict[str, Optional[int]],
    state: str,
) -> List[dict]:
    """Enable or disable AD accounts found for the specified username."""
    if state not in ACCOUNT_STATE_VALUES_CODES:
        raise ExabeamConnectorException(f"Invalid account state: {state}")

    results = []
    uac_value = ACCOUNT_STATE_VALUES_CODES[state]

    user_entries = get_user_info(
        server=server,
        bind_user=bind_user,
        password=password,
        domains_dict=domains_dict,
        target_username=target_username,
        domain_policy_cache=domain_policy_cache,
    )

    if not user_entries:
        raise ExabeamConnectorException("User not found")

    with create_connection(server, bind_user, password) as connection:
        for entry in user_entries:
            try:
                dn = entry["details"]["distinguished_name"]
                domain = entry["details"]["domain"]
                sam = entry["details"]["sAMAccountName"]

                connection.modify(
                    dn, {"userAccountControl": [(ldap3.MODIFY_REPLACE, [uac_value])]}
                )

                if connection.result.get("result") != 0:
                    raise ExabeamConnectorException(
                        f"LDAP modify failed: {connection.result}"
                    )

                results.append(
                    {
                        "success": True,
                        "domain": domain,
                        "sAMAccountName": sam,
                        "distinguished_name": dn,
                        "exception": None,
                    }
                )

            except Exception as e:
                results.append(
                    {
                        "success": False,
                        "domain": entry["details"].get("domain"),
                        "sAMAccountName": entry["details"].get("sAMAccountName"),
                        "distinguished_name": entry["details"].get("distinguished_name"),
                        "exception": str(e),
                    }
                )

    return results


def main(ldap_authentication_data: dict, target_usernames: List[str], enabled: bool) -> dict:
    """Top-level entry point to enable or disable user accounts."""
    timestamp = Time.now().isoformat()

    # Empty input fallback
    if not target_usernames:
        return {
            "success": True,
            "status": "success",
            "message": "No users provided; nothing to process.",
            "timestamp": timestamp,
            "results": [],
            "errors": [],
        }

    # ----- Get Instance Configuration Fields -----
    server_address = ldap_authentication_data.get("server_address")
    bind_user = ldap_authentication_data.get("username", "")
    bind_password = ldap_authentication_data.get("password", "")
    use_ssl = ldap_authentication_data.get("use_ssl", False)
    if isinstance(use_ssl, str):
        use_ssl = use_ssl.lower() in ('t', 'true')
    port = 636 if use_ssl else 389

    domains = ldap_authentication_data.get("domains", "")
    domains = [d.strip() for d in str(domains).split(",") if d.strip()]

    server = ldap3.Server(
        host=server_address,
        port=port,
        get_info=ldap3.ALL,
        allowed_referral_hosts=[("*", True)],
        use_ssl=use_ssl,
    )

    # ----- Build domains_dict (DNS domain -> base DN) -----
    if not domains:
        default_nc = (
            (getattr(server, "info", None) and server.info.other.get("defaultNamingContext"))
            or []
        )
        base_dn = default_nc[0] if default_nc else ""
        if not base_dn:
            raise ExabeamConnectorException(
                "No domains provided and defaultNamingContext could not be determined."
            )

        domain = base_dn.lower().replace("dc=", "").replace(",", ".")
        domains_dict = {domain: base_dn}
    else:
        domains_dict = {domain: to_base_dn(domain) for domain in domains}

    results = []
    errors = []
    seen_users = set()
    domain_policy_cache: Dict[str, Optional[int]] = {}

    target_state = "Enabled" if enabled else "Disabled"

    for target_username in target_usernames:
        item_timestamp = Time.now().isoformat()

        try:
            change_results = change_account_state(
                server=server,
                bind_user=bind_user,
                password=bind_password,
                domains_dict=domains_dict,
                target_username=target_username,
                domain_policy_cache=domain_policy_cache,
                state=target_state,
            )

            for r in change_results:
                dedupe_key = (r["sAMAccountName"], r["domain"])
                if dedupe_key in seen_users:
                    continue
                seen_users.add(dedupe_key)

                results.append(
                    {
                        "target": target_username,
                        "success": r["success"],
                        "message": (
                            f"Account {target_state.lower()} successfully."
                            if r["success"]
                            else "Failed to update account state."
                        ),
                        "timestamp": item_timestamp,
                        "details": {
                            "sAMAccountName": r["sAMAccountName"],
                            "domain": r["domain"],
                            "distinguished_name": r["distinguished_name"],
                            "state": target_state,
                        },
                        "exception": r["exception"],
                    }
                )

                if r["exception"]:
                    errors.append(f"{target_username}@{r['domain']}: {r['exception']}")

        except ExabeamConnectorException as e:
            errors.append(f"{target_username}: {e}")
            results.append(
                {
                    "target": target_username,
                    "success": False,
                    "message": "Failed to update account state.",
                    "timestamp": item_timestamp,
                    "details": {
                        "sAMAccountName": None,
                        "domain": None,
                        "state": target_state,
                    },
                    "exception": str(e),
                }
            )

    success_count = sum(1 for r in results if r["success"])
    failure_count = len(results) - success_count

    if failure_count == 0:
        status = "success"
        success = True
        message = "All account state changes completed successfully."
    elif success_count > 0:
        status = "partial_success"
        success = False
        message = "Some account state changes failed."
    else:
        status = "failure"
        success = False
        message = "All account state changes failed."

    return {
        "success": success,
        "status": status,
        "message": message,
        "timestamp": timestamp,
        "results": results,
        "errors": errors,
    }
